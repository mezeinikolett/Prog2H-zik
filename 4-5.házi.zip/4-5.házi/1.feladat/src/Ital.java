/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public abstract class Ital{

    public Ital() {
    }
    
    public abstract String mibolKeszult();
    public abstract String milyenIzu();
    
}
