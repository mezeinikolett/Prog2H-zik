/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Main {
    
     public static Aszu[] puttony(Bor [] b){                
        int szamol=0;
        for(int i=0;i<b.length;i++){                
            if(b[i] instanceof Aszu) {                      
                Aszu a=(Aszu) b[i];                         
                if(a.getPuttonySzam()==5) {
                    szamol++;                                
                }
            }
        }
        
        Aszu[] vissza=new Aszu [szamol];                     
        int index=0;                                        
        
        for(int i=0;i<b.length;i++){
            if(b[i] instanceof Aszu) {
                Aszu a=(Aszu) b[i];
                if(a.getPuttonySzam()==5) {
                    vissza[index]=a;                        
                    index++;                                
                }
            }
            
        }
        return vissza;

    }
    
    
    public static void main(String[] args) {
        
        Bor [] bor=new Bor []{
            new Bor("fehér","40 hold","félédes",20),
            new Bor("fehér","35 hold","édes",18),
            new Bor("vörös","30 hold","száraz",15),
            new Bor("vörös","25 hold","félszáraz",13),
            new Aszu(9,"20 hold",10),
            new Aszu(6,"15 hold",7),
            new Aszu(4,"10 hold",5)

    };
    
            Aszu[] tomb=puttony(bor);                      
            for (Aszu a : tomb) {
                System.out.println(a);
        }

        
    }
    
   
}

