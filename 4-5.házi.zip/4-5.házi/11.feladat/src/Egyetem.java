
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Egyetem implements Comparable<Egyetem>{
    List<Hallgató> h=new ArrayList();
    List<Oktató> o=new ArrayList();

    
    public List<Hallgató> legfiatalabbak(List<Hallgató> h){
        return null;
                
    }

    @Override
    public int compareTo(Egyetem t) {
        return this.compareTo(t);
                
               
    }
    
    
}
