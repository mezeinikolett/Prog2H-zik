
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Main {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Hozzavalo> hozzavalo = new ArrayList<>();
        while(sc.hasNextLine()){
            String[] sor = sc.nextLine().split(";");
            if(sor[0].equals("0"))
                break;
            int darab = Integer.parseInt(sor[1]);
            Hozzavalo tmp = null;
            for (Hozzavalo h : hozzavalo) {
                if(h.hozzavalok.equals(sor[0])){
                    tmp = h;
                    break;
                }
            }
            if(tmp != null){
                tmp.darabszam += darab;
            } else {
                hozzavalo.add(new Hozzavalo(sor[0], darab));
            }
        }
        Collections.sort(hozzavalo);
        for (Hozzavalo h : hozzavalo) {
            System.out.println(h);
        }
    }
}

    

    
