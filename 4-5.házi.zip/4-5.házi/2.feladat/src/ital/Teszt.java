﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ital;

/**
 *
 * @author Niki
 */
public class Teszt {
    
    public static void main(String[] args) {
       
        Ital [] ital=new Ital [] {
                new Ital("Coca-Cola","12.5",390),
                new Ital("Fanta","17.5",380),
                new Ital("Lipton Ice Tea","15",330),
                new SzeszesItal("Törley Pezsgő", "0.75", 899, 11),
                new SzeszesItal("Löwenbräu Sör ", "0.5", 190, 4),
                new SzeszesItal("Egri Bikavér Vörösbor", "0.75", 399, 12),
                new SzeszesItal("Unicum Gyógynövénylikőr", "0.5", 2950, 40),
                new SzeszesItal("Kalinka Vodka", "0.7", 3649, 37.5),
                new SzeszesItal("Körte Pálinka", "0.2", 1199, 40)
            
        };
        
        
        SzeszesItal [] t=Dolgozat.metódus(ital);
        for (SzeszesItal a : t) {
            System.out.println(a);    
        }
    }
   
}
    
