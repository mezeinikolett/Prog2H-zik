/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Magdi
 */
public class Tartós extends Termék{

    public Tartós(String név, double ár, String egység) {
        super(név, ár, egység);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Tartós)){
            return false;
        }
        
        Tartós e = (Tartós) obj;
        
        return this.getNév().equals(e.getNév()) && this.getÁr()==(e.getÁr()) && this.getEgység().equals(e.getEgység());
    }

    @Override
    public String toString() {
        return this.getNév() + " " + this.getÁr() + " Ft, " + this.getMennyiség() + " " + this.getEgység();
    }

    
}