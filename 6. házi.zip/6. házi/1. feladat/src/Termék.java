/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Magdi
 */
public class Termék implements Comparable<Termék> {

    private String név;
    private String egység;
    private double ár;
    private int mennyiség;

    public Termék(String név, double ár, String egység) {
        this.név = név;
        this.egység = egység;
        this.ár = ár;
    }

    public String getNév() {
        return név;
    }

    public void setNév(String név) {
        this.név = név;
    }

    public String getEgység() {
        return egység;
    }

    public void setEgység(String egység) {
        this.egység = egység;
    }

    public double getÁr() {
        return ár;
    }

    public void setÁr(double ár) {
        this.ár = ár;
    }

    public int getMennyiség() {
        return mennyiség;
    }

    public void setMennyiség(int mennyiség) {
        this.mennyiség = mennyiség;
    }

    @Override
    public String toString() {
        return  név +  egység +  ár + mennyiség ;
    }

    @Override
    public int compareTo(Termék t) {
        if (this instanceof Élelmiszer && !(t instanceof Tartós)) {
            Élelmiszer e1 = (Élelmiszer) this;
            Élelmiszer e2 = (Élelmiszer) t;

            if (e1.getNév().equals(e2.getNév())) {
                return Integer.compare(e1.getSzavatosság(), e2.getSzavatosság());
            } else {
                return e1.getNév().compareTo(e2.getNév());
            }
        } else {
            return this.getNév().compareTo(t.getNév());
        }
    }

    @Override
    public int compareTo(Termék o) {

    }

}
