/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Élelmiszer extends Termék {

    private int szavatosság;

    public Élelmiszer(String név, double ár, String egység, int szavatosság) {
        super(név, ár, egység);
        this.szavatosság = szavatosság;
    }

    public int getSzavatosság() {
        return szavatosság;
    }

    public void setSzavatosság(int szavatosság) {
        this.szavatosság = szavatosság;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Élelmiszer)) {
            return false;
        }

        Élelmiszer e = (Élelmiszer) obj;

        return this.getNév().equals(e.getNév()) && this.getÁr() == (e.getÁr()) && this.getEgység().equals(e.getEgység()) && this.getSzavatosság() == (e.getSzavatosság());
    }

    @Override
    public String toString() {
        return this.getNév() + " " + this.getÁr() + " Ft, szavatossaga:" + this.getSzavatosság() + ", " + this.getMennyiség() + " " + this.getEgység();
    }
}