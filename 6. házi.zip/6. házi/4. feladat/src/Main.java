/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Niki
 */
public class Main {

    public static void main(String[] args) {

        List<Mérlegelés> cegekListaja = new ArrayList<Mérlegelés>();

        try {
            FileReader fr = new FileReader(new File("sample.txt"));            
            BufferedReader buffer = new BufferedReader(fr);

            String sor;

            while ((sor = buffer.readLine()) != null) {
                String[] adatok = sor.split(":");

                Mérlegelés m = new Mérlegelés();

                if (cegekListaja.contains(m)) {
                    cegekListaja.get(cegekListaja.indexOf(m)).setÉves_árbevétel(cegekListaja.get(cegekListaja.indexOf(m)).getÉves_árbevétel() + Integer.parseInt(adatok[3]));
                    
                } else {
                    m.setÉves_árbevétel(Integer.parseInt(adatok[3]));
                    
                    cegekListaja.add(m);
                }
            }
            
            buffer.close();

        } catch (IOException i) {
            System.out.println("Hibás fájl!");
        }

            for (Mérlegelés m : cegekListaja) {
            System.out.println(m);
        }
    }
}