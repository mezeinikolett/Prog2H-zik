
import java.util.Objects;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Mérlegelés{
    
    private String cégnév;
    private String telephely;
    private int éves_árbevétel;

    public Mérlegelés(String cégnév, String telephely, int éves_árbevétel) {
        this.cégnév = cégnév;
        this.telephely = telephely;
        this.éves_árbevétel = éves_árbevétel;
    }

  
    public String getCégnév() {
        return cégnév;
    }

    public void setCégnév(String cégnév) {
        this.cégnév = cégnév;
    }

    public String getTelephely() {
        return telephely;
    }

    public void setTelephely(String telephely) {
        this.telephely = telephely;
    }

    public int getÉves_árbevétel() {
        return éves_árbevétel;
    }

    public void setÉves_árbevétel(int éves_árbevétel) {
        this.éves_árbevétel = éves_árbevétel;
    }

    @Override
    public String toString() {
        return cégnév + ( telephely) + ':'+ éves_árbevétel;
    }

   

    @Override
    public boolean equals(Object obj) {
        if (obj==null || !(obj instanceof Mérlegelés)){
        return false;
    }
        Mérlegelés m = (Mérlegelés)obj;
        return (this.cégnév.equals(m.getCégnév()) && this.telephely.equals(m.getTelephely()));
          
       
  
    }   
    

}

 