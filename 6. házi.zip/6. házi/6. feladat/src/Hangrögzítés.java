
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Hangrögzítés {
    
    private String állomásazonosító;
    private String megfigyelések;

    public Hangrögzítés(String állomásazonosító, String megfigyelések) {
        this.állomásazonosító = állomásazonosító;
        this.megfigyelések = megfigyelések;
    }

    public String getÁllomásazonosító() {
        return állomásazonosító;
    }

    public void setÁllomásazonosító(String állomásazonosító) {
        this.állomásazonosító = állomásazonosító;
    }

    public String getMegfigyelések() {
        return megfigyelések;
    }

    public void setMegfigyelések(String megfigyelések) {
        this.megfigyelések = megfigyelések;
    }
    
    public List<Integer> oroszlanÜvöltésMérőpont(){
        
        List<Integer> l=new ArrayList<>();
        
        for(int i=0; i<this.megfigyelések.length(); i++){
                if(this.megfigyelések.charAt(i)=='O'){
                    l.add(i);
                }
                
        }
         return l;
                 
    } 
    
    
}
