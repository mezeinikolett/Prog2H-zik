
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Main {
    
    public static void oroszlanSzamol(List<Hangrögzítés> l) {

        List <Integer> tmp=l.get(0).oroszlanÜvöltésMérőpont(); 
        for(Hangrögzítés i:l)
            tmp.retainAll(i.oroszlanÜvöltésMérőpont());  
        
        System.out.println(tmp.size());     
               
    }
    
    
    public static void main(String[] args){
        
        List<Hangrögzítés> h= new ArrayList<>();
        
        try {
            FileReader fr = new FileReader(new File("sample.txt"));
            BufferedReader br = new BufferedReader(fr);

            String sor;
            while ((sor = br.readLine()) != null) {
                if (sor.equals("END")) {
                    oroszlanSzamol(h);
                    
                    h.clear();
                    
                } else {

                    String[] részek = sor.split(":");
                    Hangrögzítés  á= new Hangrögzítés(részek[0], részek[1]);
                    h.add(á);

                }

            }
        } catch (IOException e) {
            e.printStackTrace();

        }

    }
}

