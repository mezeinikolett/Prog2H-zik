
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Kéktúra implements Comparable{
    private String turista_neve;
    private List<String> szakasz;

    public Kéktúra(String turista_neve) {
        this.turista_neve = turista_neve;
        this.szakasz = new ArrayList<String>();
    }

    public String getTurista_neve() {
        return turista_neve;
    }

    public void setTurista_neve(String turista_neve) {
        this.turista_neve = turista_neve;
    }

    public List<String> getSzakasz() {
        return szakasz;
    }

    public void setSzakasz(List<String> szakasz) {
        this.szakasz = szakasz;
    }

    @Override
    public String toString() {
        return turista_neve;
    }
    
    @Override
    public boolean equals(Object obj){
        if (obj == null || !(obj instanceof Kéktúra)){
            return false;
        }
        
        Kéktúra k = (Kéktúra) obj;
        
        return this.getTurista_neve().equals(k.getTurista_neve());
    }
    
    @Override
    public int compareTo(Object obj){
        
        Kéktúra k = (Kéktúra) obj;
        
        return this.getTurista_neve().compareTo(k.getTurista_neve());
    }
}
    

