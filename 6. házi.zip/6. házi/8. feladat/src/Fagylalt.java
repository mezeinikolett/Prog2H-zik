/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niki
 */
public class Fagylalt {
    private String íz;
    private int ár;

    public Fagylalt(String íz) {
        this.íz = íz;
    }

    public String getÍz() {
        return íz;
    }

    public void setÍz(String íz) {
        this.íz = íz;
    }

    public int getÁr() {
        return ár;
    }

    public void setÁr(int ár) {
        this.ár = ár;
    }

    @Override
    public String toString() {
        return  íz + "; " + ár;
    }
    
    @Override
    public boolean equals(Object obj){
        if (obj == null || !(obj instanceof Fagylalt)){
            return false;
        }
        
        Fagylalt f = (Fagylalt) obj;
        
        return this.íz.equals(f.getÍz());
    }
}
