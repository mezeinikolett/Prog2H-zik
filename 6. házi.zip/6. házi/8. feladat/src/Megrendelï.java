
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Magdi
 */
public class Megrendelő {
    private String megrendelő;
    private List<Fagylalt> fagylaltok;

    public Megrendelő(String nev) {
        this.megrendelő = megrendelő;
        this.fagylaltok = new ArrayList<Fagylalt>();
    }

    public String getMegrendelő() {
        return megrendelő;
    }

    public void setMegrendelő(String megrendelő) {
        this.megrendelő = megrendelő;
    }

    public List<Fagylalt> getFagylaltok() {
        return fagylaltok;
    }

    public void setFagylaltok(List<Fagylalt> fagylaltok) {
        this.fagylaltok = fagylaltok;
    }

    @Override
    public String toString() {
        return megrendelő + "; "+fagylaltok;
    }
}
